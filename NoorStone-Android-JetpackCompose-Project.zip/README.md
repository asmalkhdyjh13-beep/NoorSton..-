# NOOR STONE | نور ستون - تطبيق أندرويد أصلي (Jetpack Compose)

هذا هو المشروع الكامل لتطبيق قناة كرتون "نور ستون" للأندرويد، مبرمج بلغة Kotlin وواجهات Jetpack Compose الحديثة، مع دعم كامل للغة العربية RTL ومشغل فيديو عالي الجودة ExoPlayer Media3.

## متطلبات التشغيل وبناء ملف APK:
1. قم بفك ضغط هذا المجلد على جهازك.
2. افتح برنامج **Android Studio** (نسخة Ladybug أو Koala أو أحدث).
3. اختر **Open** ثم حدد مجلد المشروع المفكوك.
4. انتظر حتى ينتهي Android Studio من مزامنة ملفات Gradle (Gradle Sync).
5. تأكد من ضبط إصدار JDK على **Java 17** من خلال:
   `Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK`.

## خطوات بناء وتثبيت ملف APK:
### 1. بناء ملف Debug APK للتجربة الفورية:
افتح نافذة Terminal داخل Android Studio واكتب:
```bash
./gradlew assembleDebug
```
سيتم إنشاء ملف الـ APK في المسار:
`app/build/outputs/apk/debug/app-debug.apk`

### 2. بناء ملف Release APK للنشر والإنتاج:
```bash
./gradlew assembleRelease
```
سيتم إنشاء ملف APK مُحسّن وجاهز للنشر في:
`app/build/outputs/apk/release/app-release-unsigned.apk`

## الميزات البرمجية المضمنة في هذا المشروع:
- واجهة عربية أصيلة مع اتجاه كامل من اليمين لليسار (RTL Native Layout Direction).
- عالم أزرق وذهبي كرتوني جذاب مستوحى من هوية القناة (Blue & Gold Cartoon Theme).
- مكتبة مسلسلات وحلقات متكاملة.
- مشغل فيديو احترافي مع ExoPlayer 1.4.1.
- بحث صوتي عربي مدعوم بمحرك التعرف على الصوت (Android SpeechRecognizer).
- لوحة تحكم وإدارة محتوى آمنة للمشرف برمز حماية مشفر، مع منع المشاهدين من التعديل أو الرفع.
