# Proguard rules for Noor Stone Cartoon
-keep class com.noorstone.cartoon.data.model.** { *; }
-dontwarn androidx.media3.**
