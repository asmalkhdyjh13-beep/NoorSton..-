package com.noorstone.cartoon.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noorstone.cartoon.ui.theme.NoorDeepNavy
import com.noorstone.cartoon.ui.theme.NoorGoldAmber
import com.noorstone.cartoon.ui.theme.NoorGoldPrimary
import com.noorstone.cartoon.ui.theme.NoorRoyalBlue
import java.util.Locale

@Composable
fun VoiceSearchDialog(
    onDismiss: () -> Unit,
    onSpeechResult: (String) -> Unit
) {
    var recognizedText by remember { mutableStateOf("اضغط على الميكروفون وتحدث باللغة العربية...") }
    var isListening by remember { mutableStateOf(false) }

    // مشغل نية التعرف على الصوت باللغة العربية
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        isListening = false
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull() ?: ""
            if (spokenText.isNotBlank()) {
                recognizedText = spokenText
                onSpeechResult(spokenText)
            }
        }
    }

    fun launchVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "قل اسم الكرتون أو الحلقة في نور ستون...")
        }
        isListening = true
        speechLauncher.launch(intent)
    }

    Surface(
        color = NoorDeepNavy.copy(alpha = 0.95f),
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.align(Alignment.End)
            ) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = NoorGoldPrimary)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "البحث الصوتي الذكي في نور ستون",
                color = NoorGoldPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(30.dp))

            // الميكروفون التفاعلي الدائري الذهبي
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(NoorRoyalBlue)
                    .border(3.dp, NoorGoldPrimary, CircleShape)
                    .clickable { launchVoiceRecognition() }
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "تحدث الآن",
                    tint = NoorGoldPrimary,
                    modifier = Modifier.size(60.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = recognizedText,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "أمثلة للبحث: 'الحلقة الأولى'، 'فرسان الكهف'، 'الحجر الذهبي'",
                color = NoorGoldAmber,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
