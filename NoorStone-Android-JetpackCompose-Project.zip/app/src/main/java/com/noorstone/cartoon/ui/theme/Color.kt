package com.noorstone.cartoon.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان عالم كرتون "نور ستون" - Blue & Gold Cartoon World
val NoorDeepNavy = Color(0xFF070E1E)       // أزرق كوني داكن
val NoorMidnightBlue = Color(0xFF0F1E3D)   // أزرق ليلي
val NoorRoyalBlue = Color(0xFF1B3B6F)      // أزرق ملكي ساطع
val NoorCyanGlow = Color(0xFF00E5FF)       // وميض ياقوت بلوري

// ألوان الذهب الكرتوني المتوهج
val NoorGoldPrimary = Color(0xFFFFD700)    // ذهب خالص ساطع
val NoorGoldAmber = Color(0xFFFFB300)      // كهرمان ذهبي
val NoorGoldBright = Color(0xFFFFF176)     // بريق ذهبي
val NoorGoldDark = Color(0xFFC69214)       // ذهب عتيق

// ألوان الواجهة والحالات
val SurfaceDark = Color(0xFF0B1426)
val SurfaceCard = Color(0xFF132240)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentSuccess = Color(0xFF10B981)
val AccentDanger = Color(0xFFEF4444)
