package com.noorstone.cartoon

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.noorstone.cartoon.ui.screens.HomeScreen
import com.noorstone.cartoon.ui.theme.NoorStoneTheme
import com.noorstone.cartoon.viewmodel.CartoonViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NoorStoneTheme {
                val viewModel: CartoonViewModel = viewModel()
                val seriesList by viewModel.seriesList.collectAsState()
                val episodes by viewModel.episodes.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    HomeScreen(
                        seriesList = seriesList,
                        episodes = episodes,
                        featuredEpisode = episodes.firstOrNull(),
                        onEpisodeClick = { /* تشغيل الفيديو في مشغل ExoPlayer */ },
                        onSeriesClick = { /* فتح تفاصيل المسلسل */ },
                        onVoiceSearchClick = { viewModel.setVoiceSearching(true) }
                    )
                }
            }
        }
    }
}
