package com.noorstone.cartoon.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val NoorStoneColorScheme = darkColorScheme(
    primary = NoorGoldPrimary,
    onPrimary = NoorDeepNavy,
    primaryContainer = NoorRoyalBlue,
    onPrimaryContainer = NoorGoldBright,
    secondary = NoorGoldAmber,
    onSecondary = NoorDeepNavy,
    background = NoorDeepNavy,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary
)

@Composable
fun NoorStoneTheme(
    content: @Composable () -> Unit
) {
    // تفعيل الاتجاه من اليمين إلى اليسار (RTL) تلقائياً لدعم اللغة العربية الأصيلة
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = NoorStoneColorScheme,
            typography = Typography,
            content = content
        )
    }
}
