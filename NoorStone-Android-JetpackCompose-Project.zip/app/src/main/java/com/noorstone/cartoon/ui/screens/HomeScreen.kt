package com.noorstone.cartoon.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.noorstone.cartoon.data.model.Episode
import com.noorstone.cartoon.data.model.Series
import com.noorstone.cartoon.ui.theme.*

@Composable
fun HomeScreen(
    seriesList: List<Series>,
    episodes: List<Episode>,
    featuredEpisode: Episode?,
    onEpisodeClick: (Episode) -> Unit,
    onSeriesClick: (Series) -> Unit,
    onVoiceSearchClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NoorDeepNavy),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // بانر الحلقة المميزة اليوم
        featuredEpisode?.let { feat ->
            item {
                FeaturedEpisodeBanner(
                    episode = feat,
                    onPlayClick = { onEpisodeClick(feat) }
                )
            }
        }

        // أحدث مسلسلات قناة نور ستون
        item {
            SectionHeader(title = "مسلسلات نور ستون الكرتونية", subtitle = "عالم مليء بالسحر والمغامرات")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(seriesList) { series ->
                    SeriesCard(series = series, onClick = { onSeriesClick(series) })
                }
            }
        }

        // الحلقات الجديدة
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "أحدث الحلقات المعروضة", subtitle = "شاهد الآن بأعلى جودة وصوت نقي")
        }

        items(episodes) { episode ->
            EpisodeRowItem(episode = episode, onClick = { onEpisodeClick(episode) })
        }
    }
}

@Composable
fun FeaturedEpisodeBanner(episode: Episode, onPlayClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(16.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, Brush.linearGradient(listOf(NoorGoldPrimary, NoorCyanGlow)), RoundedCornerShape(20.dp))
            .clickable { onPlayClick() }
    ) {
        AsyncImage(
            model = episode.thumbnailUrl,
            contentDescription = episode.title,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, NoorDeepNavy.copy(alpha = 0.95f))
                    )
                )
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Surface(
                color = NoorGoldPrimary,
                shape = RoundedCornerShape(50),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Text(
                    text = "حلقة اليوم المميزة ★",
                    color = NoorDeepNavy,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Text(
                text = episode.title,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = episode.seriesTitle,
                color = NoorGoldAmber,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(
            text = title,
            color = NoorGoldPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            text = subtitle,
            color = TextSecondary,
            fontSize = 12.sp
        )
    }
}

@Composable
fun SeriesCard(series: Series, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(150.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column {
            Box(modifier = Modifier.height(180.dp).fillMaxWidth()) {
                AsyncImage(
                    model = series.coverUrl,
                    contentDescription = series.arabicTitle,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                series.badge?.let { badge ->
                    Surface(
                        color = NoorGoldAmber,
                        shape = RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text(
                            text = badge,
                            color = NoorDeepNavy,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Text(
                text = series.arabicTitle,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
fun EpisodeRowItem(episode: Episode, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(width = 110.dp, height = 75.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                AsyncImage(
                    model = episode.thumbnailUrl,
                    contentDescription = episode.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Surface(
                    color = NoorDeepNavy.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                ) {
                    Text(
                        text = episode.duration,
                        color = NoorGoldPrimary,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = episode.title,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )
                Text(
                    text = episode.seriesTitle,
                    color = NoorGoldAmber,
                    fontSize = 11.sp
                )
            }
        }
    }
}
