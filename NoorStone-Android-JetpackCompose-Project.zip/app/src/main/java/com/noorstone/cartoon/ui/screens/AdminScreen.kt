package com.noorstone.cartoon.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noorstone.cartoon.data.model.Episode
import com.noorstone.cartoon.data.model.UserRole
import com.noorstone.cartoon.ui.theme.*

@Composable
fun AdminScreen(
    currentRole: UserRole,
    episodes: List<Episode>,
    onLoginAdmin: (String) -> Boolean,
    onLogoutAdmin: () -> Unit,
    onAddEpisode: (Episode) -> Unit,
    onDeleteEpisode: (String) -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    if (currentRole != UserRole.ADMINISTRATOR) {
        // شاشة الدخول الآمنة للمشرف فقط
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NoorDeepNavy)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "قفل الأمان",
                        tint = NoorGoldPrimary,
                        modifier = Modifier.size(50.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "لوحة إدارة قناة نور ستون",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NoorGoldPrimary
                    )
                    Text(
                        text = "الدخول محمي ومخصص لمدير القناة فقط. المشاهدون لا يمكنهم الرفع أو التعديل.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it },
                        label = { Text("رمز مرور المشرف (PIN)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    errorMessage?.let { err ->
                        Text(text = err, color = AccentDanger, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val success = onLoginAdmin(pinInput)
                            if (!success) {
                                errorMessage = "رمز المرور غير صحيح. يرجى المحاولة مجدداً."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NoorGoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تسجيل الدخول كمدير", color = NoorDeepNavy, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    } else {
        // شاشة لوحة تحكم المشرف النشطة
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(NoorDeepNavy)
                .padding(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "لوحة المشرف المعتمدة ✓",
                            color = NoorGoldPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "صلاحيات النشر وإدارة الفيديوهات مفعلة",
                            color = AccentSuccess,
                            fontSize = 12.sp
                        )
                    }
                    Button(
                        onClick = onLogoutAdmin,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentDanger)
                    ) {
                        Text("خروج")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = NoorGoldPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = NoorDeepNavy)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("رفع ونشر حلقة كرتونية جديدة", color = NoorDeepNavy, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "الحلقات المنشورة في القناة (" + episodes.size + ")",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            items(episodes) { ep ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = ep.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = ep.seriesTitle + " • " + ep.duration, color = NoorGoldAmber, fontSize = 12.sp)
                        }
                        IconButton(onClick = { onDeleteEpisode(ep.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف الحلقة", tint = AccentDanger)
                        }
                    }
                }
            }
        }
    }
}
