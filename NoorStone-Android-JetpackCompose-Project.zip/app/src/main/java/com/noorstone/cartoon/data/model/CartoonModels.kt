package com.noorstone.cartoon.data.model

data class Series(
    val id: String,
    val title: String,
    val arabicTitle: String,
    val category: String,
    val categoryLabel: String,
    val description: String,
    val coverUrl: String,
    val bannerUrl: String,
    val totalEpisodes: Int,
    val rating: Float,
    val year: Int,
    val badge: String? = null
)

data class Episode(
    val id: String,
    val seriesId: String,
    val seriesTitle: String,
    val title: String,
    val episodeNumber: Int,
    val seasonNumber: Int = 1,
    val duration: String,
    val thumbnailUrl: String,
    val videoUrl: String,
    val description: String,
    val views: Long = 0,
    val likes: Long = 0,
    val isPublished: Boolean = true,
    val isFeatured: Boolean = false,
    val tags: List<String> = emptyList()
)

enum class UserRole {
    VIEWER,       // المشاهد العادي: مشاهدة فقط، ممنوع الرفع والتعديل
    ADMINISTRATOR // المشرف: إدارة كاملة، إضافة وحذف ونشر
}
