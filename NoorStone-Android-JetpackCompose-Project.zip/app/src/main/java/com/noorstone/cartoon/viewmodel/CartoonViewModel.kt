package com.noorstone.cartoon.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.noorstone.cartoon.data.model.Episode
import com.noorstone.cartoon.data.model.Series
import com.noorstone.cartoon.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class CartoonViewModel : ViewModel() {

    // حالة المستخدم ودوره (الافتراضي: مشاهد بدون صلاحيات تعديل)
    private val _currentUserRole = MutableStateFlow(UserRole.VIEWER)
    val currentUserRole: StateFlow<UserRole> = _currentUserRole.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isVoiceSearching = MutableStateFlow(false)
    val isVoiceSearching: StateFlow<Boolean> = _isVoiceSearching.asStateFlow()

    private val _selectedCategory = MutableStateFlow("all")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _episodes = MutableStateFlow<List<Episode>>(emptyList())
    val episodes: StateFlow<List<Episode>> = _episodes.asStateFlow()

    private val _seriesList = MutableStateFlow<List<Series>>(emptyList())
    val seriesList: StateFlow<List<Series>> = _seriesList.asStateFlow()

    // التحقق من رمز مرور المشرف السري
    fun loginAsAdmin(pin: String): Boolean {
        if (pin == "admin1234") {
            _currentUserRole.value = UserRole.ADMINISTRATOR
            return true
        }
        return false
    }

    fun logoutAdmin() {
        _currentUserRole.value = UserRole.VIEWER
    }

    // إضافة حلقة جديدة - مسموح للمشرف فقط
    fun addEpisode(episode: Episode): Result<Unit> {
        if (_currentUserRole.value != UserRole.ADMINISTRATOR) {
            return Result.failure(SecurityException("فقط المشرف يملك صلاحية نشر الحلقات"))
        }
        _episodes.value = listOf(episode) + _episodes.value
        return Result.success(Unit)
    }

    // حذف حلقة - مسموح للمشرف فقط
    fun deleteEpisode(episodeId: String): Result<Unit> {
        if (_currentUserRole.value != UserRole.ADMINISTRATOR) {
            return Result.failure(SecurityException("فقط المشرف يملك صلاحية حذف المحتوى"))
        }
        _episodes.value = _episodes.value.filter { it.id != episodeId }
        return Result.success(Unit)
    }

    // تحديث نص البحث الصوتي المسموع بالعربية
    fun onVoiceResultReceived(recognizedArabicText: String) {
        _searchQuery.value = recognizedArabicText
        _isVoiceSearching.value = false
    }

    fun setVoiceSearching(active: Boolean) {
        _isVoiceSearching.value = active
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(cat: String) {
        _selectedCategory.value = cat
    }
}
